var AUTH0_CLIENT_ID='aVaEKNo1bNVQe8AGde1LdY4YIPMPJw9S';
var AUTH0_DOMAIN='lovoco.auth0.com';
var AUTH0_CALLBACK_URL=location.href;